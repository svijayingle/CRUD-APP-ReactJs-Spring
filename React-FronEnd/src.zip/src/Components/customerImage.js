import React from 'react';
import customerimage from './Images/customerimage.jpg'

console.log(customerimage); 

function CustomeImage() {
  return <img src={customerimage} alt="customer" />;
}

export default CustomeImage;
