import React from "react";
import axios from "axios";
import './Form.css'

export default class RegisterForm extends React.Component {
    constructor(props) {
      super(props);
      this.state =  {
        name: "",
        email: "",
        mobile: "",
        balance :"",
        acc_no:"",
        showForm:false
      };
    }
    showAddCustomers = e=> {  
        const { showForm } = this.state;  
        this.setState({  
          showForm: !showForm,  
        });  
    };
    onNameChange = e => {
        this.setState({
          name: e.target.value
        });
      };
    
      onEmailChange = e => {
        this.setState({
          email: e.target.value
        });
      };
      onMobileChange = e => {
        this.setState({
          mobile: e.target.value
        });
      };
      onBalanceChange = e => {
        this.setState({
          balance: e.target.value
        });
      };
      onACCChange = e => {
        this.setState({
            acc_no: e.target.value
        });
      };
      handleSubmit = e => {
        e.preventDefault();
        const data = {
          name: this.state.name,
          email: this.state.email,
          mobile: this.state.mobile,
          balance:this.state.balance,
          acc_no:this.state.acc
        };
        axios
          .post("api/create", data)
          .then(res => console.log(res))
          .catch(err => console.log(err));
          alert("Customer Added");
            const showForm = this.state.showForm
          this.setState({
              showForm : !showForm
          })
      };
    render() {
        const { showForm } = this.state;
      return (
          <center>
              <button type="button" className="btn btn-outline-dark" onClick={this.showAddCustomers}> Add Customer </button>{"   "}
              {showForm? <div className="welcome-form">
                    <div className="welcome-form-heading"><h2>Registration Form</h2></div>
                    <form onSubmit={this.handleSubmit} name="registration-form">
                        <br/>
                        <label> Name :</label>
                        <input type='text'  name='name' onChange={this.onNameChange}/>
                        <br/>
                        <br/>
                        <label>ACC No. :</label>
                        <input type='text' name='acc' onChange={this.onACCChange} />
                        <br/>
                        <br/>
                        <label>Balanace :</label>
                        <input type='text' name='balance' onChange={this.onBalanceChange}/>
                        <br/>
                        <br/>
                        <label>Email :</label>
                        <input type='text'name='email'onChange={this.onEmailChange}/>
                        <br/>
                        <br/>
                        <label>Mobile :</label>
                        <input type='text' name='mobile' onChange={this.onMobileChange}/>
                        <br/>
                        <br/>
                        <input type='submit' name='submit'/>
                    </form>
                    </div>:
              <div></div>} 
                
        </center>
      );
    }
  }