import React from "react";
function Greet(){

    return(
        <div>Hello World !!</div>
    );
}

export default Greet;