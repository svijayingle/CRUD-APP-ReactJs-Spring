import './App.css';
import React from 'react';
import Customers from './Components/Customers';
import Welcome from './Components/Welcome';
import CustomeImage from './Components/customerImage';
import Header from './Components/Header';
import RegisterForm from './Components/RegisterForm';
import { BrowserRouter as Router, Route,Switch } from "react-router-dom";
function App() {
    
    return (
      <Router>
        <div className="App">
            <Header></Header>
            <CustomeImage></CustomeImage>
            <Welcome></Welcome>
        </div>
            <Switch>
              <Route path="/ViewAllCustomers" component={Customers}></Route>
              <Route path="/addCustomer" component={RegisterForm}></Route>  
            </Switch>
      </Router>
    )
}
export default App;
